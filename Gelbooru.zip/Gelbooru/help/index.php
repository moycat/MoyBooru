<?php
	require "../inv.header.php";
	require "../includes/header.php";
?>
<div id="content">
<div class="help">
  <h1>Help</h1>
  <ul class="link-page">
      <li><a href="posts.php">&raquo; Posts</a></li>
      <li><a href="ratings.php">&raquo; Ratings</a></li>
      <li><a href="forum.php">&raquo; Forum</a></li>
    </ul>
</div></div></body></html>